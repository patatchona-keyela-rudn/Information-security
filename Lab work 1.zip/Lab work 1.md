**РОССИЙСКИЙ УНИВЕРСИТЕТ ДРУЖБЫ НАРОДОВ**

**Факультет физико-математических и естественных наук**

**Кафедра прикладной информатики и теории вероятностей**

 

 

 

 

 

**ОТЧЕТ** 

**по лабораторной работе №1**

*дисциплина**: Математические основы защиты информации*         

 

 

 

 

 

 

 

 

Студент: Кейела Патачона                  

 

​                                            Группа: Нпммд-02-21 

 

Преподаватель: Кулябов Д.С.                   

 

 

 

 

**МОСКВА**

2021 г.

# Задание 1

Реализовать шифра Цезаря с произвольным ключом k (с сдвигом к)

```python
letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"

key = int(input("Please enter your key: "))

text_to_encode = input("Text to encode: ")

encoded_text = ''

for char in text_to_encode:

 encoded_text += letters[(key + letters.index(char))%53]

print(encoded_text)
```

# Задание 2

Реализовать шифр Атбаша

```python
reverse_letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'[::-1] + 'abcdefghijklmnopqrstuvwxyz'[::-1]

text_to_encode = input("Text to encode: ")

encoded_text = ''

for char in text_to_encode:

 encoded_text += reverse_letters[letters.index(char)]

print(encoded_text)
```

